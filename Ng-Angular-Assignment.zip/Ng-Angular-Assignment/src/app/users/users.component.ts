import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { User } from '../user.interface';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  user: User [] = [
    {
      name: 'Harsh Sagar Garg',
      username: 'hsg01',
      email: 'harsh@gmail.com',
    },
    {
      name: 'John Doe',
      username: 'jd01',
      email: 'john_doe@gmail.com',
    },
    {
      name: 'Mary Jane',
      username: 'jane01',
      email: 'jane.mary@gmail.com',
    },
    {
      name: 'Alice Neville',
      username: 'alice01',
      email: 'alice@gmail.com',
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }
}
