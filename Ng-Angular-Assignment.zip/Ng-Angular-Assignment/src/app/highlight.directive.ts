import { HostListener, Directive, HostBinding } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})

export class HighlightDirective
{
 private isHighlighted = false;

  constructor(){

   }

  @HostBinding('class.highlight')
  get shouldHighlight() {
    return this.isHighlighted;
  }
  
  @HostListener('mouseout')
  onMouseOut() {
    this.isHighlighted = false;
  }
  @HostListener('mouseover')
  onMouseOver() {
    this.isHighlighted = true;
  }

}
