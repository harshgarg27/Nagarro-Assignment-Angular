# AngularAssignment

This project was generated with [Angular CLI](https://github.com/angular/angular-cli)

## Problem Statement

### Assignment-1

1.	Create a new component named “users” using @angular/cli.
2.	Inside the component, create an array of users. Each user shall have a name, username and email.
3.	Bind list of users using <table> tag.
4.	Use <ng-template> tag to display a message in case no users are available.

### Assignment-2

1.	Create a directive named “highlighter”.
2.	This directive should be responsible to do the following:
a.	Add a yellow background to email in the above table if user places her mouse over an email in the table.
b.	Remove that yellow background from email if user moves her mouse out of that same email.

#### Created by Harsh Sagar Garg